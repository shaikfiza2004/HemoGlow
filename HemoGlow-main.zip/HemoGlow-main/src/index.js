import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import Loginsignup from './Components/Loginsignup';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
function HomePage() {
  return (
    <div className="main-container">

      {/* Header */}
      <header className="header">
        <div className="logo">🩸 HemoGlow</div>
        <nav className="nav-links">
          <a href="#home">Home</a>
          <a href="/donate">Donate Now</a>
          <a href="#request">Want Blood</a>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="hero-section" id="home">
        <div className="hero-content">
          <img src="logoblood.png" alt="App Logo" className="hero-logo" />
          <h1>Welcome to HemoGlow</h1>
          <p>Connecting blood donors with those in urgent need. Your single drop can save lives.</p>
          <button className="donate-btn">Donate Now</button>
        </div>
      </section>

      {/* Info Section */}
      <section className="info-section">
        <h2>About HemoGlow</h2>
        <p>
          HemoGlow is a life-saving initiative designed to simplify and speed up the blood donation process.
          We support patients like pregnant women, infants, and cancer warriors by connecting them with suitable donors.
        </p>
        <p>
          Features include: donor search, real-time requests, location-based results, and SMS alerts.
        </p>
      </section>

      {/* Why Donate Section */}
      <section className="why-donate">
        <h2>Why Should You Donate Blood?</h2>
        <ul>
          <li>It saves up to 3 lives with each donation</li>
          <li>Improves your own heart health</li>
          <li>Creates a reliable supply for emergencies</li>
        </ul>
      </section>

      <section className="services-section">
  <h2>Our Services</h2>
  <div className="services-grid">
    <div className="service-card">
      <i className="fas fa-hand-holding-medical"></i>
      <h4>Instant Donor Matching</h4>
      <p>Quickly connect with the nearest eligible donors through smart filtering.</p>
    </div>
    <div className="service-card">
      <i className="fas fa-hospital"></i>
      <h4>Partner Hospitals</h4>
      <p>We’re trusted by 150+ hospitals and clinics across the country.</p>
    </div>
    <div className="service-card">
      <i className="fas fa-map-marker-alt"></i>
      <h4>Real-time Maps</h4>
      <p>Locate donors and donation centers instantly with live map support.</p>
    </div>
    <div className="service-card">
      <i className="fas fa-bell"></i>
      <h4>Emergency Alerts</h4>
      <p>Receive urgent blood request alerts via SMS and app notifications.</p>
    </div>
  </div>

  <h3>Our Reach</h3>
<div className="info-card">
  <p><strong>0</strong> Partner Hospitals</p>
  <p><strong>0</strong> Registered Donors</p>
  <p><strong>24/7</strong> Service Availability</p>
</div>

<h3>Our Vision</h3>
<div className="info-card fade-in">
  <p>To build a <strong>smart, fast, and caring</strong> blood donation network accessible to everyone in need.</p>
</div>

<h3>Our Core Values</h3>
<div className="info-card fade-in">
  <p><span className="core-value">❤️ Compassion</span> • <span className="core-value">⚡ Efficiency</span> • <span className="core-value">🤝 Trust</span> • <span className="core-value">🚪 Accessibility</span></p>
</div>

<button className="contact-btn">📞 Contact Us for Emergency</button>

</section>


      {/* FAQ Section */}
      <section className="faq-section">
        <h2>FAQs</h2>
        <div className="faq">
          <strong>🩺 Who can donate blood?</strong>
          <p>Anyone aged 18–65 years, in good health, and weighing over 50 kg.</p>
        </div>
        <div className="faq">
          <strong>🔄 How often can I donate?</strong>
          <p>Once every 3 months for men, and every 4 months for women.</p>
        </div>
        <div className="faq">
          <strong>🛡️ Is it safe?</strong>
          <p>Yes. Sterile equipment is used. You’ll be taken care of by professionals.</p>
        </div>
      </section>

      {/* Footer */}
      <footer className="footer">
        <div className="footer-logo">🩸 HemoGlow</div>
        <div className="icons">
          <i className="fab fa-facebook"></i>
          <i className="fab fa-instagram"></i>
          <i className="fab fa-linkedin"></i>
        </div>
       <p className="copyrightmsg">&copy; 2025 BloodCare. All Rights Reserved.</p>
      </footer>

    </div>
  );
}
function App(){
  return(
    <BrowserRouter>
    <Routes>
      <Route path="/" element={<HomePage/>}/>
      <Route path="/donate" element={<Loginsignup/>}/>
    </Routes>
    </BrowserRouter>
  );
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App/>
  </React.StrictMode>
);


